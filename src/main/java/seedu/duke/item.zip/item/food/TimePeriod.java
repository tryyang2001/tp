package seedu.duke.item.food;

public enum TimePeriod {
    Morning, Afternoon, Evening, Night
}
